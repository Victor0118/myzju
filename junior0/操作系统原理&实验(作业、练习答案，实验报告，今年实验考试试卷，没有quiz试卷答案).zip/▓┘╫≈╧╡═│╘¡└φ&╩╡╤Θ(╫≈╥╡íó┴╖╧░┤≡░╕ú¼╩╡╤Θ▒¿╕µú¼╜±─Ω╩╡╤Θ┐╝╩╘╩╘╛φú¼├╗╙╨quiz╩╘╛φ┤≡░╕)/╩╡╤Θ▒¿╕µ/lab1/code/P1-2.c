#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>
#include <semaphore.h>

#define PRODUCE_NUM 3
#define PRODUCING_NUM 5
#define CONSUME_NUM 5
#define CONSUMING_NUM 3
#define BUFFER_SIZE 8

void produce(void *arg);
void consume(void *arg);

sem_t empty,full;
int counter=0;
int buffer_ptr1=0;
int buffer_ptr2=0;
pthread_mutex_t mut1 = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t mut2 = PTHREAD_MUTEX_INITIALIZER;

struct tm time_record[BUFFER_SIZE];
int count_record[BUFFER_SIZE];
pid_t  pthreadID_record[BUFFER_SIZE];

void wait_p(int *s,int n);
void signal_p(int *s,int n);

int main(int argc, char *argv[])
{
	pthread_t id1[PRODUCE_NUM],id2[CONSUME_NUM];
	int i;
	sem_init(&full,0,0);
	sem_init(&empty,0,BUFFER_SIZE);

	for(i=0;i<PRODUCE_NUM;i++)
		pthread_create(&id1[i],NULL,(void *)produce,NULL);
	for(i=0;i<CONSUME_NUM;i++)
		pthread_create(&id2[i],NULL,(void *)consume,NULL);

	
	for(i=0;i<PRODUCE_NUM;i++)
		pthread_join(id1[i],NULL);
	for(i=0;i<CONSUME_NUM;i++)
		pthread_join(id2[i],NULL);

	exit(0);
}

void produce(void *arg)
{
	time_t sec[PRODUCING_NUM];
	struct tm t[PRODUCING_NUM];
	int i;

	for(i=0;i<PRODUCING_NUM;i++)
	{
		sec[i]=time(NULL);
		t[i]=*localtime(&sec[i]);
		sleep(1);
	}

//	wait_p(&mutex1,1);
	pthread_mutex_lock(&mut1);
//	wait_p(&empty,PRODUCING_NUM);
		

	for(i=0;i<PRODUCING_NUM;i++)
	{
		sem_wait(&empty);
		time_record[buffer_ptr1]=t[i];
		count_record[buffer_ptr1]=counter++;
		pthreadID_record[buffer_ptr1]=pthread_self();
		buffer_ptr1=(++buffer_ptr1)%BUFFER_SIZE;
		sem_post(&full);
	}

//	signal_p(&mutex1,1);
//	signal_p(&full,PRODUCING_NUM);
	pthread_mutex_unlock(&mut1);
}

void consume(void *arg)
{
	struct tm t[CONSUMING_NUM];
	pid_t p[CONSUMING_NUM];
	int c[CONSUMING_NUM];
	int i;

//	wait_p(&mutex2,1);
	pthread_mutex_lock(&mut2);
//	wait_p(&full,CONSUMING_NUM);

	for(i=0;i<CONSUMING_NUM;i++)
	{
		sem_wait(&full);
		t[i]=time_record[buffer_ptr2];
		c[i]=count_record[buffer_ptr2];
		p[i]=pthreadID_record[buffer_ptr2];
		buffer_ptr2=(++buffer_ptr2)%BUFFER_SIZE;
		sem_post(&empty);
	}

//	signal_p(&mutex2,1);
//	signal_p(&empty,CONSUMING_NUM);
	pthread_mutex_unlock(&mut2);

	for(i=0;i<CONSUMING_NUM;i++)
		printf("cycle %d , time %d:%d:%d , pid %d\n",c[i],t[i].tm_hour,t[i].tm_min,t[i].tm_sec,p[i]);	
}

