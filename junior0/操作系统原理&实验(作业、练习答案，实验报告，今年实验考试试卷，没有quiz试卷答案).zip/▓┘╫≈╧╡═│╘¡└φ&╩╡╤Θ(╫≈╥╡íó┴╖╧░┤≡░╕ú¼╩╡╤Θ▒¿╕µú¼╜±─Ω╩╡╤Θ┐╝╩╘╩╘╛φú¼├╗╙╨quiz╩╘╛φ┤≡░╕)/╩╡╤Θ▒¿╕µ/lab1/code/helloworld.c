#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/sched.h>
int init_module(void)
{
	int nr_total;
	int nr_running,nr_interruptible,nr_uninterruptible;
	int nr_stopped,nr_traced;
	int nr_zombie,nr_dead;
	int nr_unknown;
	long old_state,old_exit_state;

	struct task_struct *p=&init_task;

	nr_total=0;
	nr_running=nr_interruptible=nr_uninterruptible=0;
	nr_stopped=nr_traced=nr_unknown=0;
	nr_zombie=nr_dead=0;

	for(p=&init_task;(p=next_task(p))!=&init_task;)
	{
		nr_total++;

		old_state=p->state;
		old_exit_state=p->exit_state;

		printk("Name %s , pid %d , state %ld , ppid %s\n",p->comm,p->pid,p->state,p->parent->comm);

		switch(old_exit_state)
		{
			case EXIT_ZOMBIE:
				nr_zombie++;
				break;
			case EXIT_DEAD:
				nr_dead++;
				break;
			default:
				break;
		}

		if(old_exit_state)
			continue;

		switch(old_state)
		{
			case TASK_RUNNING:
				nr_running++;
				break;
			case TASK_INTERRUPTIBLE:
				nr_interruptible++;
				break;
			case TASK_UNINTERRUPTIBLE:
				nr_uninterruptible++;
				break;
			case TASK_STOPPED:
				nr_stopped++;
				break;
			case TASK_TRACED:
				nr_traced++;
				break;
			default:
				nr_unknown++;
				printk("task state unknown:0x%08x\n",(unsigned int ) old_state);
				break;
		}
	}

	printk("total tasks:		%4d\n",nr_total);
	printk("TASK_RUNNING:		%4d\n",nr_running);
	printk("TASK_INTERRUPTIBLE:	%4d\n",nr_interruptible);
	printk("TASK_UNINTERRUPTIBLE:	%4d\n",nr_uninterruptible);
	printk("TASK_STOPPED:		%4d\n",nr_stopped);
	printk("TASK_TRACED:		%4d\n",nr_traced);
	printk("TASK_ZOMBIE:		%4d\n",nr_zombie);
	printk("TASK_DEAD:		%4d\n",nr_dead);
	printk("unknown state:		%4d\n",nr_unknown);

	return 0;
}

void cleanup_module(void)
{
printk("<1> Goodbye!\n");
}

MODULE_LICENSE ("GPL");
