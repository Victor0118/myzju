//server.cpp
#include "define.h"
#include <stdio.h>
#include <winsock2.h>

/*global define*/
int init_ftp(SOCKET *pListenSock);
int init_data_sock(SOCKET *pDatatcps, SOCKADDR_IN *pClientAddr);
int procmd(SOCKET tcps, CmdPacket* pCmd, SOCKADDR_IN *pClientAddr);
int send_rsp(SOCKET tcps, RspnsPacket* prspns);
int re_cmd(SOCKET tcps, char* pCmd);
int file_list(SOCKET datatcps);
int file_rcd(SOCKET datatcps, WIN32_FIND_DATA* pfd);
int s_file(SOCKET datatcps, FILE* file);
int r_file(SOCKET datatcps, char* filename);
int file_quit(const char *filename);

/*struct of thread data*/
struct threadData {
	SOCKET	tcps;
	sockaddr_in clientaddr;
};

/*main function*/
int main(int argc, char* argv[]){
	SOCKET tcps_listen;
	struct threadData *pThInfo;

	/*initialize*/
	if (!init_ftp(&tcps_listen))
		return 0;

	printf("Welcome to Mini FTP Server!\nPort:%d\n...", CMD_PORT);

	/*listening*/
	for (;;){
		pThInfo = NULL;
		pThInfo = new threadData;
		if (pThInfo == NULL)
		{
			printf(" malloc space failed!\n");
			continue;
		}
		int len = sizeof(struct threadData);
		pThInfo->tcps = accept(tcps_listen, (SOCKADDR*)&pThInfo->clientaddr, &len);
		
		/*create a new require*/
		DWORD dwThreadId, dwThrdParam = 1;
		HANDLE hThread;

		hThread = CreateThread(NULL,0,ThreadFunc,pThInfo,0,&dwThreadId);
		/*return value for success*/
		if (hThread == NULL){
			printf("CreateThread failed.\n");
			closesocket(pThInfo->tcps);
			delete pThInfo;
		}
	}
	return 0;
}


/*thread function*/
DWORD WINAPI ThreadFunc(LPVOID lpParam){
	SOCKET tcps;
	sockaddr_in clientaddr;

	tcps = ((threadData *)lpParam)->tcps;
	clientaddr = ((threadData *)lpParam)->clientaddr;
	printf("socket id is %u.\n", tcps);
	printf("Serve client %s:%d\n", inet_ntoa(clientaddr.sin_addr), ntohs(clientaddr.sin_port));
	RspnsPacket rspns = { OK,"Welcome to Mini FTP Server (Windows Version)!\nIP:192.168.1.100\nPort:5021\n"
		"Avilable commands:\n""ls\t<no param>\n""pwd\t<no param>\n""cd\t<path>\n""get\t<file>\n""put\t<file>\n""quit\t<no param>\n"
	};
	send_rsp(tcps, &rspns);

	for (;;){
		CmdPacket cmd;
		if (!re_cmd(tcps, (char *)&cmd))
			break;
		if (!procmd(tcps, &cmd, &clientaddr))
			break;
	}

	/*close thread*/
	closesocket(tcps);
	delete lpParam;
	return 0;
}

/*ftp initialize*/
int init_ftp(SOCKET *pListenSock){
	WORD wVersionRequested;
	WSADATA wsaData;
	int err;
	SOCKET tcps_listen;

	wVersionRequested = MAKEWORD(2, 2);
	err = WSAStartup(wVersionRequested, &wsaData);
	if (err != 0){
		printf("Winsock initialize error!\n");
		return 0;
	}
	if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 2){
		WSACleanup();
		printf("useless Winsock wersion!\n");
		return 0;
	}

	tcps_listen = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (tcps_listen == INVALID_SOCKET){
		WSACleanup();
		printf("create Socket fail!\n");
		return 0;
	}
	SOCKADDR_IN tcpaddr;
	tcpaddr.sin_family = AF_INET;
	tcpaddr.sin_port = htons(CMD_PORT);
	tcpaddr.sin_addr.S_un.S_addr = htonl(INADDR_ANY);
	err = bind(tcps_listen, (SOCKADDR*)&tcpaddr, sizeof(tcpaddr));
	if (err != 0){
		err = WSAGetLastError();
		WSACleanup();
		printf("Socket binding error!\n");
		return 0;
	}
	err = listen(tcps_listen, 3);
	if (err != 0)
	{
		WSACleanup();
		printf("Socket listening error!\n");
		return 0;
	}
	*pListenSock = tcps_listen;
	return 1;
}

/*creating data link*/
int init_data_sock(SOCKET *pDatatcps, SOCKADDR_IN *pClientAddr)
{
	SOCKET datatcps;

	datatcps = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (datatcps == INVALID_SOCKET){
		printf("Creating data socket failed!\n");
		return 0;
	}
	SOCKADDR_IN tcpaddr;
	memcpy(&tcpaddr, pClientAddr, sizeof(SOCKADDR_IN));
	tcpaddr.sin_port = htons(DATA_PORT);
	if (connect(datatcps, (SOCKADDR*)&tcpaddr, sizeof(tcpaddr)) == SOCKET_ERROR){
		printf("Connecting to client failed!\n");
		closesocket(datatcps);
		return 0;
	}
	*pDatatcps = datatcps;
	return 1;
}

/*deal with cmd*/
int procmd(SOCKET tcps, CmdPacket* pCmd, SOCKADDR_IN *pClientAddr)
{
	SOCKET datatcps;
	RspnsPacket rspns;
	FILE* file;
	switch (pCmd->cmdid){
	case LS://ls cmd
		if (!init_data_sock(&datatcps, pClientAddr))
			return 0;
		if (!file_list(datatcps))
			return 0;
		break;
	case PWD://pwd cmd
		rspns.rspnsid = OK;
		if (!GetCurrentDirectory(RSPNS_TEXT_SIZE, rspns.text))
			strcpy(rspns.text, "Can't get current dir!\n");
		if (!send_rsp(tcps, &rspns)) return 0;
		break;
	case CD://cd cmd
		if (SetCurrentDirectory(pCmd->param)){
			rspns.rspnsid = OK;
			if (!GetCurrentDirectory(RSPNS_TEXT_SIZE, rspns.text))
				strcpy(rspns.text, "CD succeed! But can't get current dir!\n");
		}
		else{
			strcpy(rspns.text, "Can't change to that dir!");
		}
		if (!send_rsp(tcps, &rspns))
			return 0;
		break;
	case GET:
		file = fopen(pCmd->param, "rb");
		if (file){
			rspns.rspnsid = OK;
			sprintf(rspns.text, "get file %s\n", pCmd->param);
			if (!send_rsp(tcps, &rspns)){
				fclose(file);
				return 0;
			}
			else{
				if (!init_data_sock(&datatcps, pClientAddr)){
					fclose(file);
					return 0;
				}
				if (!s_file(datatcps, file)) return 0;
				fclose(file);
			}
		}
		else{
			rspns.rspnsid = ERR;
			strcpy(rspns.text, "Can't open file!\n");
			if (!send_rsp(tcps, &rspns))
				return 0;
		}
		break;
	case PUT://put cmd
		char filename[64];
		strcpy(filename, pCmd->param);
		if (file_quit(filename)){
			rspns.rspnsid = ERR;
			sprintf(rspns.text, "Remote file named %s exits!\n", filename);
			if (!send_rsp(tcps, &rspns))
				return 0;
		}
		else{
			rspns.rspnsid = OK;
			if (!send_rsp(tcps, &rspns))
				return 0;
			if (!init_data_sock(&datatcps, pClientAddr))
				return 0;
			if (!r_file(datatcps, filename))
				return 0;
		}
		break;
	case QUIT:
		printf("Client quit.\n");
		rspns.rspnsid = OK;
		strcpy(rspns.text, "Bye bye!\n");
		send_rsp(tcps, &rspns);
		return 0;
	}
	return 1;
}

int send_rsp(SOCKET tcps, RspnsPacket* prspns)
{
	if (send(tcps, (char *)prspns, sizeof(RspnsPacket), 0) == SOCKET_ERROR)
	{
		printf("Lost the connection to client!\n");
		return 0;
	}
	return 1;
}

/*recieve cmd*/
int re_cmd(SOCKET tcps, char* pCmd){
	int nRet;
	int left = sizeof(CmdPacket);

	while (left){
		nRet = recv(tcps, pCmd, left, 0);
		if (nRet == SOCKET_ERROR){
			printf("Error occurs when receiving command from client!\n");
			return 0;
		}
		if (!nRet){
			printf("Connection is closed by client!\n");
			return 0;
		}

		left -= nRet;
		pCmd += nRet;
	}

	return 1;//succeed
}

/*file cmd*/
int file_rcd(SOCKET datatcps, WIN32_FIND_DATA* pfd){
	char filerecord[MAX_PATH + 32];
	FILETIME ft;
	FileTimeToLocalFileTime(&pfd->ftLastWriteTime, &ft);
	SYSTEMTIME lastwtime;
	FileTimeToSystemTime(&ft, &lastwtime);
	char* dir = pfd->dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY ? "<DIR>" : "";
	sprintf(filerecord, "%04d-%02d-%02d %02d:%02d    %5s  %10d  %-20s\n",lastwtime.wYear,lastwtime.wMonth,lastwtime.wDay,lastwtime.wHour,lastwtime.wMinute,dir,pfd->nFileSizeLow,pfd->cFileName);
	if (send(datatcps, filerecord, strlen(filerecord), 0) == SOCKET_ERROR){
		printf("Error occurs when sending file list!\n");
		return 0;
	}
	return 1;
}

/*send file list*/
int file_list(SOCKET datatcps){
	HANDLE hff;
	WIN32_FIND_DATA fd;

	hff = FindFirstFile("*", &fd);
	/*error*/
	if (hff == INVALID_HANDLE_VALUE){
		const char* errstr = "Can't list files!\n";
		printf("List file error!\n");
		if (send(datatcps, errstr, strlen(errstr), 0) == SOCKET_ERROR){
			printf("Error occurs when sending file list!\n");
		}
		closesocket(datatcps);
		return 0;
	}

	BOOL fMoreFiles = TRUE;
	while (fMoreFiles){
		if (!file_rcd(datatcps, &fd)){
			closesocket(datatcps);
			return 0;
		}
		fMoreFiles = FindNextFile(hff, &fd);
	}

	closesocket(datatcps);
	return 1;
}

/*send file*/
int s_file(SOCKET datatcps, FILE* file)
{
	char buf[1024];
	printf("Sending file data...");
	for (;;){
		int r = fread(buf, 1, 1024, file);
		if (send(datatcps, buf, r, 0) == SOCKET_ERROR)
		{
			printf("Lost the connection to client!\n");
			closesocket(datatcps);
			return 0;
		}
		if (r<1024)//finished
			break;
	}
	closesocket(datatcps);
	printf("Done\n");
	return 1;
}

/*recieve file*/
int r_file(SOCKET datatcps, char* filename){
	char buf[1024];
	FILE* file = fopen(filename, "wb");
	if (!file){
		printf("Error occurs when open file to write!\n");
		fclose(file);
		closesocket(datatcps);
		return 0;
	}
	printf("Receiving file data...");
	while (1){
		int r = recv(datatcps, buf, 1024, 0);
		if (r == SOCKET_ERROR){
			printf("Error occurs when receiving file from client!\n");
			fclose(file);
			closesocket(datatcps);
			return 0;
		}
		if (!r)//end
			break;

		fwrite(buf, 1, r, file);
	}
	fclose(file);
	closesocket(datatcps);
	printf("Done\n");
	return 1;
}
/*file existence*/
int file_quit(const char *filename){
	WIN32_FIND_DATA fd;
	if (FindFirstFile(filename, &fd) == INVALID_HANDLE_VALUE)
		return 0;
	return 1;
}
