//client.cpp
//2015.04.10
//ele 3120102146
//gcc -o client client.cpp
//./client ip
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include "define.h"

/*extern var*/
extern int errno;

/*main function*/
int main(int argc, char *argv[]){
	RspnsPacket rspack;
	int sockfd;//sock
	struct hostent *he; struct sockaddr_in taddr;//struct var
	char cmd[10]; char data_buf[DATA_BUFSIZE];//buffer
	if (argc != 2){
		fprintf(stderr, "usage : SFTPClient hostname(or IP address)\n");
		exit(1);
	}
	if ((he = gethostbyname(argv[1])) == NULL)//dns
	{
		herror("gethostbyname");
		exit(1);
	}
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)//create
		do_err(sockfd, "socket error");
	taddr.sin_family = AF_INET;
	taddr.sin_port = htons(CMD_PORT);
	taddr.sin_addr = *(struct in_addr *)he->h_addr;
	bzero(&(taddr.sin_zero), 8);
	if (connect(sockfd, (struct sockaddr *)&taddr, sizeof(struct sockaddr)) == -1)//from server
		do_err(sockfd, "connect error");
	/*read file*/
	read_rsp(sockfd, &rspack);
	printf("%s", rspack.text);
	while (scanf("%s", cmd)){
		memset(data_buf, 0, DATA_BUFSIZE);
		switch (cmd[0])
		{
			/*list*/
		case 'list':
			list(sockfd, data_buf);
			break;
		case 'pwd':
			/*pwd*/
			if (cmd[1] == 'w')
				pwd(sockfd);
			else
				/*put*/
				put_file(sockfd, data_buf);
			break;
		case 'cd':
			/*cd*/
			cd(sockfd);
			break;
		case 'get':
			/*get*/
			get_file(sockfd, data_buf);
			break;
		case 'quit':
			/*quit*/
			quit(sockfd);
			break;
		default:
			printf("invalid command!\n");
			break;
		}
		if (cmd[0] == 'q')
			break;
	}
	close(sockfd);
}
/*close file*/
void do_err(int fd, char *msg){
	if (fd > 0)
		close(fd);
	perror(msg);
	exit(1);
}

/*read res*/
void read_rsp(int fd, RspnsPacket *ptr){
	int count = 0;
	int size = sizeof(RspnsPacket);

	while (count < size){
		int flag = read(fd, (char *)ptr + count, size - count);
		if (flag == -1)
			do_err(fd, "read response error");
		count += flag;
	}
}

/*send cmd*/
void send_cmd(int fd, CmdPacket *ptr){
	int size = sizeof(CmdPacket);
	int flag = write(fd, (char *)ptr, size);
	if (flag == -1)
		do_err(fd, "write command error");
}

/*read data*/
int r_data(int fd, char *buf, int n){
	int flag = read(fd, buf, n);
	if (flag == -1)
		do_err(fd, "read data error");
	return flag;
}

/*write to fd*/
int w_data(int fd, char *buf, int n){
	int flag = write(fd, buf, n);
	if (flag == -1)
		do_err(fd, "write data error");
	return flag;
}

/*create data link*/
int c_data_sckt(){
	int sockfd;
	struct sockaddr_in my_addr;
	int on = 1;
	/*tell*/
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
		do_err(sockfd, "socket error in c_data_sckt");
	if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (char *)&on, sizeof(on)) == -1)
		do_err(sockfd, "setsockopt error in c_data_sckt");
	my_addr.sin_family = AF_INET;
	my_addr.sin_port = htons(DATA_PORT);
	my_addr.sin_addr.s_addr = htonl(INADDR_ANY);
	bzero(&(my_addr.sin_zero), 8);
	if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof(struct sockaddr)) == -1)
		do_err(sockfd, "bind error in c_data_sckt");//error
	if (listen(sockfd, 1) == -1)
		do_err(sockfd, "listen error in c_data_sckt");//error
	return sockfd;
}
/*list*/
void list(int sockfd, char *data_buf){
	CmdPacket cmd_packet;
	int newsockfd, data_sockfd;
	struct sockaddr_in taddr;
	int sin_size;
	newsockfd = c_data_sckt();
	cmd_packet.cmdid = LS;
	send_cmd(sockfd, &cmd_packet);

	/*deal with*/
	sin_size = sizeof(struct sockaddr_in);
	if ((data_sockfd = accept(newsockfd, (struct sockaddr *)&taddr, (socklen_t *)&sin_size)) == -1)
		do_err(newsockfd, "accept error in get_file");
	/*print data*/
	while (r_data(data_sockfd, data_buf, DATA_BUFSIZE) != 0)
		printf("%s", data_buf);
	/*close*/
	close(data_sockfd);
	close(newsockfd);
}
/*deal pwd*/
void pwd(int sockfd){
	CmdPacket cmd_packet;
	RspnsPacket rspack;
	cmd_packet.cmdid = PWD;//send
	send_cmd(sockfd, &cmd_packet);
	read_rsp(sockfd, &rspack);//read
	printf("%s\n", rspack.text);
}
/*cd cmd*/
void cd(int sockfd){
	CmdPacket cmd_packet;
	RspnsPacket rspack;
	cmd_packet.cmdid = CD;//send
	scanf("%s", cmd_packet.param);
	send_cmd(sockfd, &cmd_packet);
	read_rsp(sockfd, &rspack);//recieve
	if (rspack.rspnsid == ERR)
		printf("%s", rspack.text);
}
/*get cmd*/
void get_file(int sockfd, char *data_buf){
	CmdPacket cmd_packet;
	RspnsPacket rspack;
	int newsockfd, data_sockfd;
	struct sockaddr_in taddr;
	int sin_size;
	int fd, count;
	cmd_packet.cmdid = GET;
	scanf("%s", cmd_packet.param);
	fd = open(cmd_packet.param, O_WRONLY | O_CREAT | O_EXCL);//open with create
	if (fd == -1){//tell
		if (errno == EEXIST)
			printf("%s allready exists.\n", cmd_packet.param);
		else
			printf("Can't create file %s.\n", cmd_packet.param);
		return;
	}
	newsockfd = c_data_sckt();
	send_cmd(sockfd, &cmd_packet);//send first
	read_rsp(sockfd, &rspack);//read responce
	if (rspack.rspnsid == ERR){
		printf("%s", rspack.text);
		close(newsockfd);
		close(fd);
		remove(cmd_packet.param);
		return;
	}
	sin_size = sizeof(struct sockaddr_in);//accept
	if ((data_sockfd = accept(newsockfd, (struct sockaddr *)&taddr, (socklen_t *)&sin_size)) == -1)
		do_err(newsockfd, "accept error in get_file");
	while ((count = r_data(data_sockfd, data_buf, DATA_BUFSIZE)) != 0)
		w_data(fd, data_buf, count);
	close(data_sockfd);
	close(newsockfd);
	close(fd);
}
/*put cmd*/
void put_file(int sockfd, char *data_buf){
	CmdPacket cmd_packet;
	RspnsPacket rspack;
	int newsockfd, data_sockfd;
	struct sockaddr_in taddr;
	int sin_size;
	int fd, count;
	cmd_packet.cmdid = PUT;
	scanf("%s", cmd_packet.param);
	fd = open(cmd_packet.param, O_RDONLY);//open file
	if (fd == -1){
		if (errno == ENOENT)
			printf("%s is an invalid path.\n", cmd_packet.param);
		else
			printf("Can't open file %s.\n", cmd_packet.param);
		return;
	}
	//create link
	newsockfd = c_data_sckt();
	send_cmd(sockfd, &cmd_packet);//first
	read_rsp(sockfd, &rspack);//then
	if (rspack.rspnsid == ERR){
		printf("%s", rspack.text);
		close(newsockfd);
		close(fd);
		return;
	}
	sin_size = sizeof(struct sockaddr_in);
	if ((data_sockfd = accept(newsockfd, (struct sockaddr *)&taddr, (socklen_t *)&sin_size)) == -1)
		do_err(newsockfd, "accept error in put_file");
	while ((count = r_data(fd, data_buf, DATA_BUFSIZE)) != 0)
		w_data(data_sockfd, data_buf, count);
	close(data_sockfd);
	close(newsockfd);
	close(fd);
}
/*quit cmd*/
void quit(int sockfd)
{
	CmdPacket cmd_packet;
	RspnsPacket rspack;
	cmd_packet.cmdid = QUIT;
	send_cmd(sockfd, &cmd_packet);
	read_rsp(sockfd, &rspack);
	printf("%s", rspack.text);
}
