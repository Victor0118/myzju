#ifndef DEFINE_H 
#define DEFINE_H

#define CMD_PORT 5021
#define DATA_PORT 5020
#define CMD_PARAM_SIZE 256
#define RSPNS_TEXT_SIZE 256
#define BACKLOG 10
#define DATA_BUFSIZE 4096

typedef enum
{
	LS, PWD, CD, GET, PUT, QUIT
} CmdID;

typedef struct _CmdPacket
{
	CmdID cmdid;
	char param[CMD_PARAM_SIZE];
} CmdPacket;

typedef enum
{
	OK, ERR
} RspnsID;

typedef struct _RspnsPacket
{
	RspnsID rspnsid;
	char text[RSPNS_TEXT_SIZE];
} RspnsPacket;

#endif
